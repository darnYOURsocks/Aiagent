#!/usr/bin/env bash
set -euo pipefail
# Create PDF from text and ingest
python sample/make_pdf.py sample/system_test.txt sample/system_test.pdf
curl -s -F "file=@sample/system_test.pdf" http://127.0.0.1:8000/ingest/pdf | jq
# Ask a question
curl -s -X POST http://127.0.0.1:8000/query -H "Content-Type: application/json" -d '{"query":"total price for six windows with triple glaze and deposit"}' | jq
