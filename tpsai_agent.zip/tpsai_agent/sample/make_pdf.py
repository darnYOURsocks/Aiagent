from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.pagesizes import A4
from pathlib import Path
import sys

def make_pdf(txt_path: str, pdf_path: str):
    styles = getSampleStyleSheet()
    normal = styles["Normal"]
    mono = ParagraphStyle("Mono", parent=normal, fontName="Courier", fontSize=9, leading=11)
    story = []
    with open(txt_path, "r", encoding="utf-8") as f:
        for line in f.read().splitlines():
            if line.strip() == "":
                story.append(Spacer(1,8)); continue
            if line.startswith("TP:"):
                story.append(Paragraph(f"<font name='Courier' size=8>{line}</font>", mono))
            else:
                story.append(Paragraph(line, normal)); story.append(Spacer(1,4))
    SimpleDocTemplate(pdf_path, pagesize=A4).build(story)

if __name__ == "__main__":
    txt = sys.argv[1] if len(sys.argv)>1 else "sample/system_test.txt"
    pdf = sys.argv[2] if len(sys.argv)>2 else "sample/system_test.pdf"
    make_pdf(txt, pdf)
    print("Wrote", pdf)
