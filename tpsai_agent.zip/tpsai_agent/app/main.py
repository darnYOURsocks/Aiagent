from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel
import hashlib, datetime, json
import pandas as pd
import sqlite3
from typing import List
from pathlib import Path

from .models import QueryRequest, QueryAnswer, OutlineItem, ProcedureItem
from .db import ensure_schema, get_conn, DATA_DIR
from .parser import extract_pdf_lines, parse_tpsai_lines
from .indexer import build_index, load_index
from .recomposer import add_owners, outline, procedure
from .answer import rank_with_tps, expand_to_owners

app = FastAPI(title="TPSAI Agent", version="1.0")

@app.on_event("startup")
def startup_event():
    ensure_schema()
    DATA_DIR.mkdir(exist_ok=True, parents=True)

def _insert_parsed(parsed):
    with get_conn() as conn:
        sha256 = parsed.get("sha256","")
        meta = parsed["meta"]
        conn.execute(
            "INSERT INTO documents(doc_id,title,version,author,sha256,imported_at) VALUES(?,?,?,?,?,?)",
            (meta.get("id"), meta.get("title"), meta.get("version"), meta.get("author"),
             sha256, datetime.datetime.utcnow().isoformat()+"Z")
        )
        doc_pk = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
        for b in parsed["blocks"]:
            conn.execute(
                "INSERT INTO blocks(doc_fk, block_id, kind, level, page_n, e, l, h, tps, rfc_code, text_raw) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                (doc_pk, b["block_id"], b["kind"], b["level"], b["page_n"],
                 b["e"], b["l"], b["h"], b["tps"], b["rfc_code"], b["text_raw"])
            )
        for e in parsed["edges"]:
            conn.execute(
                "INSERT INTO edges(doc_fk, src_block, rel, dst_block) VALUES (?,?,?,?)",
                (doc_pk, e["from"], e["rel"], e["to"])
            )
        conn.commit()

def _load_blocks_df() -> pd.DataFrame:
    with get_conn() as conn:
        df = pd.read_sql_query("SELECT id, block_id, kind, level, page_n, tps, rfc_code, text_raw FROM blocks ORDER BY id", conn)
    return add_owners(df)

@app.post("/ingest/pdf")
async def ingest_pdf(file: UploadFile = File(...)):
    content = await file.read()
    # SHA256
    sha256 = hashlib.sha256(content).hexdigest()
    # Parse
    lines = extract_pdf_lines(content)
    if not any(l.startswith("TP:") for l in lines):
        raise HTTPException(status_code=400, detail="No TP: control lines detected.")
    parsed = parse_tpsai_lines(lines)
    parsed["sha256"] = sha256
    _insert_parsed(parsed)

    # Rebuild index
    blocks_df = _load_blocks_df()
    build_index(blocks_df)

    return {"status": "ingested", "doc_meta": parsed["meta"], "sha256": sha256, "blocks": len(blocks_df)}

@app.get("/outline", response_model=List[OutlineItem])
def get_outline():
    blocks_df = _load_blocks_df()
    return outline(blocks_df).to_dict(orient="records")

@app.get("/procedure", response_model=List[ProcedureItem])
def get_procedure():
    blocks_df = _load_blocks_df()
    return procedure(blocks_df).to_dict(orient="records")

@app.post("/query", response_model=QueryAnswer)
def query(req: QueryRequest):
    try:
        vectorizer, X, tps, meta = load_index()
    except Exception as e:
        raise HTTPException(status_code=400, detail="Index not built yet. Ingest a PDF first.")
    hits = rank_with_tps(vectorizer, X, tps, meta, req.query, req.top_k)
    owners = expand_to_owners(hits)

    # Compose a minimal answer by stitching steps/bullets from top owners
    blocks_df = _load_blocks_df()
    fragments = []
    prov = []
    for owner in owners[:2]:  # combine up to 2 owners to keep answers concise
        subset = blocks_df[blocks_df["owner"]==owner]
        section = blocks_df[(blocks_df["block_id"]==owner) & (blocks_df["kind"].isin(["SEC","SUBSEC"]))]
        title = (section.iloc[0]["text_raw"].splitlines()[0] if len(section)>0 and section.iloc[0]["text_raw"] else owner)
        steps = [r["text_raw"] for _, r in subset[subset["kind"]=="STEP"].iterrows()]
        bullets = [r["text_raw"] for _, r in subset[subset["kind"]=="BUL"].iterrows()]
        tips = [r["text_raw"] for _, r in subset[subset["kind"]=="TIP"].iterrows()]
        if steps:
            fragments.append(f"From {title} – Steps:\n" + "\n".join(steps))
        if bullets:
            fragments.append("Bullets:\n" + "\n".join(bullets))
        if tips:
            fragments.append("Tips:\n" + "\n".join(tips))
        # provenance: the top 3 blocks that belong to this owner
        prov += [h for h in hits if h["row"].get("owner")==owner][:3]

    answer_text = "\n\n".join(fragments) if fragments else "No direct answer found; try rephrasing."
    return QueryAnswer(answer=answer_text, provenance=prov, owners=owners)
