from pydantic import BaseModel
from typing import List, Optional, Any

class QueryRequest(BaseModel):
    query: str
    top_k: int = 8

class QueryAnswer(BaseModel):
    answer: str
    provenance: List[dict]
    owners: List[str]

class OutlineItem(BaseModel):
    order_id: int
    kind: str
    level: int
    block_id: str
    title: str
    page: int
    tps: float

class ProcedureItem(BaseModel):
    owner_block_id: str
    section_title: str
    page: int
    tps: float
    steps: List[str]
    bullets: List[str]
    tips: List[str]
