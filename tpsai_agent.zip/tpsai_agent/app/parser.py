import re, hashlib, datetime
from typing import List, Dict, Any
from PyPDF2 import PdfReader

CTRL = re.compile(r"^TP:(?P<type>[A-Z]+)\|(?P<kv>.+)$")

def extract_pdf_lines(pdf_bytes: bytes) -> List[str]:
    from io import BytesIO
    reader = PdfReader(BytesIO(pdf_bytes))
    pages = []
    for p in reader.pages:
        pages.append(p.extract_text() or "")
    text = "\n".join(pages)
    lines = [ln.rstrip() for ln in text.splitlines() if ln.strip()!=""]
    return lines

def parse_tpsai_lines(lines: List[str]) -> Dict[str, Any]:
    doc_meta = {}
    blocks, edges, media = [], [], []
    page = 1
    current_block = None

    def start_block(kind, kvs):
        return {
            "block_id": kvs.get("id"),
            "kind": kind,
            "level": int(kvs.get("level", "0")) if "level" in kvs else None,
            "page_n": page,
            "e": None, "l": None, "h": None, "tps": None, "rfc_code": None,
            "text_raw": ""
        }

    for ln in lines:
        m = CTRL.match(ln.strip())
        if not m:
            if current_block is not None:
                current_block["text_raw"] += (("\n" if current_block["text_raw"] else "") + ln)
            continue

        t = m.group("type")
        kvs = {}
        for part in m.group("kv").split("|"):
            if "=" in part:
                k,v = part.split("=",1); kvs[k]=v

        if t=="DOC":
            doc_meta = kvs
        elif t=="PAGE":
            page = int(kvs.get("n", page))
        elif t in ("SEC","SUBSEC","STEP","BUL","TIP","NOTE","DEMO"):
            if current_block is not None:
                blocks.append(current_block)
            current_block = start_block(t, kvs)
        elif t in ("RFC","WEIGHT"):
            if current_block is not None:
                if t=="RFC":
                    current_block["rfc_code"] = kvs.get("code")
                    try:
                        current_block["tps"] = float(kvs.get("tps","0") or 0)
                    except:
                        current_block["tps"] = None
                else:
                    for k in ("e","l","h"):
                        try:
                            current_block[k] = float(kvs.get(k,"0") or 0)
                        except:
                            current_block[k] = None
        elif t=="LINK":
            edges.append({"from":kvs.get("from"), "rel":kvs.get("rel"), "to":kvs.get("to")})
        elif t in ("CODE","IMG","FILE"):
            media.append({"kind":t.lower(), **kvs, "page_n":page})
        elif t=="ENDDOC":
            break

    if current_block is not None:
        blocks.append(current_block)

    return {"meta":doc_meta, "blocks":blocks, "edges":edges, "media":media}
