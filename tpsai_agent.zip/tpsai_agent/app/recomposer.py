import pandas as pd

def add_owners(blocks_df: pd.DataFrame) -> pd.DataFrame:
    owner = []
    last_sec = None
    last_sub = None
    for _, r in blocks_df.iterrows():
        kind = r["kind"]
        if kind=="SEC":
            last_sec = r["block_id"]; last_sub = None
        elif kind=="SUBSEC":
            last_sub = r["block_id"]
        owner.append(last_sub if last_sub else last_sec)
    out = blocks_df.copy()
    out["owner"] = owner
    return out

def outline(blocks_df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for _, r in blocks_df.iterrows():
        if r["kind"] in ("SEC","SUBSEC"):
            title = (r["text_raw"].splitlines()[0] if r["text_raw"] else "").strip()
            rows.append({
                "order_id": int(r["id"]),
                "kind": r["kind"],
                "level": int(r["level"]) if r["level"] is not None else 0,
                "block_id": r["block_id"],
                "title": title,
                "page": int(r["page_n"]),
                "tps": float(r["tps"]) if r["tps"] is not None else 0.0
            })
    return pd.DataFrame(rows)

def procedure(blocks_df: pd.DataFrame) -> pd.DataFrame:
    df = add_owners(blocks_df)
    proc = []
    for owner_id in df["owner"].dropna().unique():
        subset = df[df["owner"]==owner_id]
        sec_row = df[(df["block_id"]==owner_id) & (df["kind"].isin(["SEC","SUBSEC"]))]
        sec_title = (sec_row.iloc[0]["text_raw"].splitlines()[0] if len(sec_row)>0 and sec_row.iloc[0]["text_raw"] else "").strip() if len(sec_row)>0 else ""
        sec_page = int(sec_row.iloc[0]["page_n"]) if len(sec_row)>0 else 1
        sec_tps = float(sec_row.iloc[0]["tps"]) if len(sec_row)>0 and sec_row.iloc[0]["tps"] is not None else 0.0
        steps = [r["text_raw"] for _, r in subset[subset["kind"]=="STEP"].iterrows()]
        bullets = [r["text_raw"] for _, r in subset[subset["kind"]=="BUL"].iterrows()]
        tips = [r["text_raw"] for _, r in subset[subset["kind"]=="TIP"].iterrows()]
        if steps or bullets or tips or len(sec_row)>0:
            proc.append({
                "owner_block_id": owner_id, "section_title": sec_title, "page": sec_page, "tps": sec_tps,
                "steps": steps, "bullets": bullets, "tips": tips
            })
    return pd.DataFrame(proc)
