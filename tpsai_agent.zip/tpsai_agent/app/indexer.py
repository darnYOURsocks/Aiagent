import json, pickle
from pathlib import Path
from typing import List, Dict
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from scipy import sparse

DATA_DIR = Path(__file__).resolve().parents[1] / "data"
INDEX_DIR = DATA_DIR / "index"

def build_search_corpus(blocks_df: pd.DataFrame) -> pd.DataFrame:
    def make_doc(r):
        hdr = f"{r['kind']} {r['block_id']} "
        return hdr + (r["text_raw"] or "")
    df = blocks_df.copy()
    df["doc_text"] = df.apply(make_doc, axis=1)
    return df

def build_index(blocks_df: pd.DataFrame):
    INDEX_DIR.mkdir(exist_ok=True, parents=True)
    df = build_search_corpus(blocks_df)
    vectorizer = TfidfVectorizer(ngram_range=(1,2), min_df=1)
    X = vectorizer.fit_transform(df["doc_text"].tolist())
    # TPS boost vector
    tps = df["tps"].fillna(0.0).tolist()
    # Save artifacts
    with open(INDEX_DIR / "vectorizer.pkl","wb") as f:
        pickle.dump(vectorizer, f)
    sparse.save_npz(INDEX_DIR / "tfidf.npz", X)
    with open(INDEX_DIR / "tps_boost.json","w") as f:
        json.dump(tps, f)
    with open(INDEX_DIR / "meta.json","w") as f:
        json.dump({"doc_rows": df.to_dict(orient="records")}, f)

def load_index():
    import numpy as np
    from sklearn.metrics.pairwise import cosine_similarity
    with open(INDEX_DIR / "vectorizer.pkl","rb") as f:
        vectorizer = pickle.load(f)
    X = sparse.load_npz(INDEX_DIR / "tfidf.npz")
    with open(INDEX_DIR / "tps_boost.json") as f:
        tps = json.load(f)
    with open(INDEX_DIR / "meta.json") as f:
        meta = json.load(f)["doc_rows"]
    return vectorizer, X, tps, meta
