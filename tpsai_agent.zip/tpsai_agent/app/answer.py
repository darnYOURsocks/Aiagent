from typing import List, Dict, Tuple
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity

def rank_with_tps(vectorizer, X, tps, meta, query: str, top_k:int=8) -> List[Dict]:
    qv = vectorizer.transform([query])
    sims = cosine_similarity(qv, X).ravel()
    tps = np.array(tps)
    boost = 1.0 + 0.2 * tps
    score = sims * boost
    idx = score.argsort()[::-1][:top_k]
    return [{"idx": int(i), "score": float(score[i]), "row": meta[i]} for i in idx]

def expand_to_owners(hits: List[Dict]) -> List[str]:
    owners = []
    for h in hits:
        owners.append(h["row"].get("owner","") or h["row"].get("block_id"))
    # Preserve order, dedupe
    out = []
    for o in owners:
        if o and o not in out:
            out.append(o)
    return out
