import sqlite3
from pathlib import Path
from typing import Tuple

DATA_DIR = Path(__file__).resolve().parents[1] / "data"
DB_PATH = DATA_DIR / "tpsai.db"

def get_conn() -> sqlite3.Connection:
    DATA_DIR.mkdir(exist_ok=True, parents=True)
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    return conn

SCHEMA_SQL = '''
CREATE TABLE IF NOT EXISTS documents(
  id INTEGER PRIMARY KEY,
  doc_id TEXT,
  title TEXT,
  version TEXT,
  author TEXT,
  sha256 TEXT,
  imported_at TEXT
);
CREATE TABLE IF NOT EXISTS blocks(
  id INTEGER PRIMARY KEY,
  doc_fk INTEGER,
  block_id TEXT,
  kind TEXT,
  level INTEGER,
  page_n INTEGER,
  e REAL, l REAL, h REAL, tps REAL,
  rfc_code TEXT,
  text_raw TEXT,
  FOREIGN KEY(doc_fk) REFERENCES documents(id)
);
CREATE TABLE IF NOT EXISTS edges(
  id INTEGER PRIMARY KEY,
  doc_fk INTEGER,
  src_block TEXT,
  rel TEXT,
  dst_block TEXT,
  FOREIGN KEY(doc_fk) REFERENCES documents(id)
);
CREATE TABLE IF NOT EXISTS media(
  id INTEGER PRIMARY KEY,
  doc_fk INTEGER,
  block_id TEXT,
  kind TEXT,
  name TEXT,
  hash TEXT,
  lang TEXT,
  alt TEXT,
  page_n INTEGER,
  FOREIGN KEY(doc_fk) REFERENCES documents(id)
);
'''

def ensure_schema():
    with get_conn() as conn:
        conn.executescript(SCHEMA_SQL)
        conn.commit()
