#!/usr/bin/env bash
uvicorn app.main:app --reload --port 8000
